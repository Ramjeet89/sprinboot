package ecomdashboard.in.ecomdashboard.service;

import java.util.HashMap;
import java.util.List;

import ecomdashboard.in.ecomdashboard.entity.CompanyRevenue;
import ecomdashboard.in.ecomdashboard.entity.EmployeeInfomation;
import ecomdashboard.in.ecomdashboard.entity.OrderCollectionStatus;
import ecomdashboard.in.ecomdashboard.entity.OrderReceived;
import ecomdashboard.in.ecomdashboard.entity.ProductCatagory;

public interface DashboardService {

	HashMap<String, Object> getTodayRevenueDash();

	List<ProductCatagory> getBestCatagory();

	List<OrderReceived> getAllOrderReceived();

	List<OrderCollectionStatus> getOrderCollection();

	List<EmployeeInfomation> getAllEmployee();
	
	EmployeeInfomation getEmployee(final String pk);

	EmployeeInfomation addEmployee(EmployeeInfomation employeeInfomation);

	EmployeeInfomation updateEmployee(EmployeeInfomation employeeInfomation);

	void deleteEmployee(EmployeeInfomation employeeInfomation);
}
