package ecomdashboard.in.ecomdashboard.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ProductCatagory")
public class ProductCatagory extends KeyEntity{

	private String catagoryName;
	private int percentage;
	private boolean bestCatagory;

	public String getCatagoryName() {
		return catagoryName;
	}

	public void setCatagoryName(String catagoryName) {
		this.catagoryName = catagoryName;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	public boolean isBestCatagory() {
		return bestCatagory;
	}

	public void setBestCatagory(boolean bestCatagory) {
		this.bestCatagory = bestCatagory;
	}
}
