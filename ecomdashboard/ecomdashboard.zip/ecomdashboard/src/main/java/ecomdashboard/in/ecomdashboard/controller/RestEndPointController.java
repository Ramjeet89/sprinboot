package ecomdashboard.in.ecomdashboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ecomdashboard.in.ecomdashboard.entity.EmployeeInfomation;
import ecomdashboard.in.ecomdashboard.service.DashboardService;

@RestController
public class RestEndPointController {

	@Autowired
	private DashboardService dashboardService;

	@RequestMapping("/employees")
	public List<EmployeeInfomation> getAllEmp() {
		return dashboardService.getAllEmployee();
	}

	@RequestMapping(method = RequestMethod.POST, value = "/employee/add")
	public String saveEmployee(@RequestBody EmployeeInfomation employeeInfomation) {
		if (dashboardService.addEmployee(employeeInfomation) != null) {
			return "Employee Data saved successfully";
		} else {
			return "Error Saving Employee Info";
		}
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/employee/delete")
	public String deleteEmp(@RequestParam(name = "empId", required = true) String pk) {
		try {
			dashboardService.deleteEmployee(dashboardService.getEmployee(pk));
			return "deleted";
		} catch (Exception e) {
			return "error";
		}
	}
}
