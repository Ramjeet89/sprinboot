package ecomdashboard.in.ecomdashboard.service.impl;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.Local;
import org.springframework.stereotype.Service;

import ecomdashboard.in.ecomdashboard.entity.CompanyRevenue;
import ecomdashboard.in.ecomdashboard.entity.EmployeeInfomation;
import ecomdashboard.in.ecomdashboard.entity.OrderCollectionStatus;
import ecomdashboard.in.ecomdashboard.entity.OrderReceived;
import ecomdashboard.in.ecomdashboard.entity.ProductCatagory;
import ecomdashboard.in.ecomdashboard.repositories.CompanyRevenueRepository;
import ecomdashboard.in.ecomdashboard.repositories.EmployeeInformationRepository;
import ecomdashboard.in.ecomdashboard.repositories.OrderCollectionStatusRepository;
import ecomdashboard.in.ecomdashboard.repositories.OrderReceivedRepository;
import ecomdashboard.in.ecomdashboard.repositories.ProductCatagoryRepository;
import ecomdashboard.in.ecomdashboard.service.DashboardService;

@Service
public class DashboardImpl implements DashboardService {

	@Autowired
	private CompanyRevenueRepository companyRevenueRepository;

	@Autowired
	private EmployeeInformationRepository employeeInformationRepository;

	@Autowired
	private OrderCollectionStatusRepository orderCollectionStatusRepository;

	@Autowired
	private OrderReceivedRepository orderReceivedRepository;

	@Autowired
	private ProductCatagoryRepository productCatagoryRepository;

	/*
	 * @Override public List<CompanyRevenue> getTodayRevenueDash() { return
	 * companyRevenueRepository.findAll(); }
	 */

	@Override
	public HashMap<String, Object> getTodayRevenueDash() {
		HashMap<String, Object> populateCompanyRev = new HashMap<>();
		List<CompanyRevenue> companyRevenueList = companyRevenueRepository.findAll();
		List<String> lable = new ArrayList<>();
		List<String> _revenue = new ArrayList<>();
		double totalMargin = 0;
		double totalExpense = 0;
		double totalRevenue = 0;

		Locale locale = new Locale("en", "US");
		NumberFormat currenctFormatter = NumberFormat.getCurrencyInstance(locale);

		for (CompanyRevenue companyRevenue : companyRevenueList) {
			lable.add(companyRevenue.get_month());
			_revenue.add(String.valueOf(companyRevenue.getRevenue()));
			totalExpense = totalExpense + companyRevenue.getExpense();
			totalMargin = totalMargin + companyRevenue.getMargin();
			totalRevenue = totalRevenue + companyRevenue.getRevenue();
		}
		populateCompanyRev.put("crLabels", lable.toString());
		populateCompanyRev.put("crRevenue", _revenue.toString());
		populateCompanyRev.put("totalExpense", currenctFormatter.format(totalExpense));
		populateCompanyRev.put("totalMargin", currenctFormatter.format(totalMargin));
		populateCompanyRev.put("totalRevenue", currenctFormatter.format(totalRevenue));

		return populateCompanyRev;
	}

	@Override
	public List<OrderReceived> getAllOrderReceived() {
		return orderReceivedRepository.findAll();
	}

	@Override
	public List<OrderCollectionStatus> getOrderCollection() {
		return orderCollectionStatusRepository.findAll();
	}

	@Override
	public List<EmployeeInfomation> getAllEmployee() {
		return employeeInformationRepository.findAll();
	}

	@Override
	public List<ProductCatagory> getBestCatagory() {
		return productCatagoryRepository.findBestCatagory(true);
	}

	// Added new methods
	@Override
	public EmployeeInfomation addEmployee(EmployeeInfomation employeeInfomation) {
		return employeeInformationRepository.save(employeeInfomation);
	}

	@Override
	public EmployeeInfomation updateEmployee(EmployeeInfomation employeeInfomation) {
		return employeeInformationRepository.save(employeeInfomation);
	}

	@Override
	public void deleteEmployee(EmployeeInfomation employeeInfomation) {
		employeeInformationRepository.delete(employeeInfomation);
	}

	@Override
	public EmployeeInfomation getEmployee(String pk) {
		return employeeInformationRepository.findByPk(pk);
	}

}
