package ecomdashboard.in.ecomdashboard.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ecomdashboard.in.ecomdashboard.service.DashboardService;

@Controller
public class ThymleafController {

	@Autowired
	private DashboardService dashboardService;

	@GetMapping
	public String getDashDetails(Model model) {
		model.addAttribute("cr", dashboardService.getTodayRevenueDash());
		model.addAttribute("ei", dashboardService.getAllEmployee());
		return "/index";
	}
}
